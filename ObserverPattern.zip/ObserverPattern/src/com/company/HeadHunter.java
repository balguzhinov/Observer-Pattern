package com.company;

import java.util.ArrayList;
import java.util.List;

public class HeadHunter implements Observed{

    List<String> vaccancies = new ArrayList<>();

    List<Observer> candidates = new ArrayList<>();

    public void addVaccancy(String vaccancy){
        this.vaccancies.add(vaccancy);
        notifyObserver();
    }
    public void deleteVaccancy(String vaccancy){
        this.vaccancies.remove(vaccancy);
        notifyObserver();
    }

    @Override
    public void addObserver(Observer observer) {
        this.candidates.add(observer);
    }

    @Override
    public void deleteObserver(Observer observer) {
        this.candidates.remove(observer);
    }

    @Override
    public void notifyObserver() {
        for(Observer observer : candidates){
            observer.Observe(this.vaccancies);
        }
    }
}
