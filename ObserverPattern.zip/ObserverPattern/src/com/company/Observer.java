package com.company;

import java.util.List;

public interface Observer {
    public void Observe(List<String> vaccancies);
}
