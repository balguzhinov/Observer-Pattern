package com.company;

public class Main {

    public static void main(String[] args) {
        HeadHunter positions = new HeadHunter();

        positions.addVaccancy("iOS develeper");
        positions.addVaccancy("UX/UI Designer");
        positions.addVaccancy("Java Developer");

        Observer FirstCandidate = new Candidate("Abay");
        Observer SecondCandidate = new Candidate("Dias");
        Observer ThirdCandidate = new Candidate("Erhan");
        Observer FourthCandidate = new Candidate("Shyngyskhan");

        positions.addObserver(FirstCandidate);
        positions.addObserver(SecondCandidate);
        positions.addObserver(ThirdCandidate);
        positions.addObserver(FourthCandidate);

        positions.addVaccancy("Product Manager");

        positions.deleteVaccancy("Java Developer");
    }
}
