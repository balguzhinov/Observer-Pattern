package com.company;
import java.util.List;

public class Candidate implements Observer{
    String name;

    public Candidate(String name){
        this.name = name;
    }

    @Override
    public void Observe(List<String> vaccancies) {
        System.out.println("Dear " + name + "\n We have some news on vaccancies: " + vaccancies);
    }
}
